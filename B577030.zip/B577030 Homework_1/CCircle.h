#pragma once
#include "CShape.h"

class CCircle : public CShape {
public:
	CPoint start_point;
	CPoint end_point;
	virtual void Draw(CDC* dc, CDC* memDC, CDC* bitDC) override;

public:
	CCircle(CPoint start_point, CPoint end_point);
	CCircle();
	~CCircle();
};

