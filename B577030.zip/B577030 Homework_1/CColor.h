#pragma once
#include "CShape.h"

class CColor : public CShape {
public:
	CPoint start_point;
	CPoint end_point;
	virtual void Draw(CDC* dc, CDC* memDC, CDC* bitDC) override;

public:
	CColor(CPoint start_point, CPoint end_point);
	CColor();
	~CColor();
};

