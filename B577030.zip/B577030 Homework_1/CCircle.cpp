#include "pch.h"
#include "CCircle.h"

CCircle::CCircle() {

}

CCircle::CCircle(CPoint Start_point, CPoint End_point) {
	start_point = Start_point;
	end_point = End_point;
}

CCircle::~CCircle() {

}

void CCircle::Draw(CDC* dc, CDC* memDC, CDC* bitDC) {
	CRect rect(start_point, end_point);
	CBrush blueBrush(RGB(0, 0, 255));

	memDC->SelectObject(&blueBrush);
	memDC->Ellipse(rect);
}

