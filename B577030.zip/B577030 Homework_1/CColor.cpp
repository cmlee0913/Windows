#include "pch.h"
#include "CColor.h"

CColor::CColor() {

}

CColor::CColor(CPoint Start_point, CPoint End_point) {
	start_point = Start_point;
	end_point = End_point;
}

CColor::~CColor() {

}

void CColor::Draw(CDC* dc, CDC* memDC, CDC* bitDC) {
	for (int x = start_point.x; x < start_point.x + 200; x++) {
		for (int y = start_point.y; y < start_point.y + 200; y++) {
			if ((x - 100 - start_point.x) * (x - 100 - start_point.x) + (y - 100 - start_point.y) * (y - 100 - start_point.y) < 100 * 100) {
				memDC->SetPixelV(x - 100, y - 100, RGB(x - start_point.x, 0, y - start_point.y));
			}
		}
	}
}