#include "pch.h"
#include "CShape.h"


CShape::CShape() {

}

CShape::~CShape() {

}

