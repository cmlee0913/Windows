﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// B577030Homework2.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_B577030Homework2TYPE        130
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_RED                          32774
#define ID_GREEN                        32775
#define ID_BLUE                         32776
#define ID_32777                        32777
#define ID_32778                        32778
#define ID_ELI                          32779
#define ID_RECT                         32780
#define ID_ECLI                         32781
#define ID_32782                        32782
#define ID_BLACK                        32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        310
#define _APS_NEXT_COMMAND_VALUE         32802
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
