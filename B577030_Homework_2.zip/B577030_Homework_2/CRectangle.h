#pragma once
#include "CShape.h"

class CRectangle : public CShape
{
public:
	virtual void Draw(CDC* memDC);

public:
	CRectangle(CPoint D_point, COLORREF M_color);
	CRectangle();
	~CRectangle();
};

