#include "pch.h"
#include "CShape.h"

CShape::CShape() {

}

CShape::~CShape() {

}

void CShape::Draw(CDC* memDC) {
	
}