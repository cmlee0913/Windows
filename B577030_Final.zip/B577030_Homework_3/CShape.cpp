#include "pch.h"
#include "CShape.h"


CShape::CShape(CPoint p_point, CPoint point, enum Type type) {
	past_point = p_point;
	draw_point = point;
	s_type = type;
	isSelect = false;
}

CShape::CShape(bool select) {
	isSelect = select;
}

CShape::~CShape() {

}

void CShape::Draw(CDC* memDC) {
	CPen pen1(0, 2, RGB(255, 0, 0));
	CPen pen2(0, 2, RGB(0, 0, 0));
	if (isSelect) {
		memDC->SelectObject(&pen1);
	}
	else if (!isSelect) {
		memDC->SelectObject(&pen2);
	}
	if (s_type == Quadrangle) {
		memDC->Rectangle(draw_point.x - 40, draw_point.y - 40, draw_point.x + 40, draw_point.y + 40);
	}
}